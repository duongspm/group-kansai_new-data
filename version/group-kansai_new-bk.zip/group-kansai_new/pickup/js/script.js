$(function() {
	$('.slider').slick({
		// fade: true,
		// slidesToShow: 1,
		// slidesToScroll: 1,
		// autoplay: false,
		// autoplaySpeed: 1000,
		// speed: 4000,
		// infinite: true,
		// dots: true,
		// arrows: true

		autoplay: false,
        fade: true,
        dots: true,
        speed: 1000
	})
});